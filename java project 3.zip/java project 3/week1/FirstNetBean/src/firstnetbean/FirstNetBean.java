
package firstnetbean;

public class FirstNetBean {

    public static void main(String[] args) {
        System.out.println("First NetBeans Project");
    }
    
}
