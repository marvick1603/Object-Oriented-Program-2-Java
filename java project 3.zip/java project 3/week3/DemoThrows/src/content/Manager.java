
package content;

public class Manager {
    
}
