package content;

public interface Second {

    String secondStuff();
}
