package content;

   

public abstract class AParent {
    
    public abstract String stuff(); 
// abstract method doesnt have body
//    {
//        return "This is stuff";
//    }
}
