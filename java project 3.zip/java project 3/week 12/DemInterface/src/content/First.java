package content;

public interface First {
    
    int NUM = 10;
    String firstStuff();

//    public String firstStuff() {
//        return "This is first";
//    }
}
