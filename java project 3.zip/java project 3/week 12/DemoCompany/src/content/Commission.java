package content;

public interface Commission {
double RATE =0.10;

}
