package content;

public abstract class Student  { // while creating abstract method class must be abstract too
    
    public abstract String display();
}
