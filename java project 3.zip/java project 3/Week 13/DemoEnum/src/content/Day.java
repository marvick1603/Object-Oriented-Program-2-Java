package content;

/**
 *
 * @author jaini
 */
public enum Day {

    Monday,
    Tuesday,
    Wednesday,
    Thursday,
    Friday,
    Saturday,
    sunday,;


}
