/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package content;

import javafx.stage.Stage;
//import twobuttons.TwoButtons;

/**
 *
 * @author patel
 */
public class StageOne extends Stage {
    public StageOne(){
        setHeight(300);
        setWidth(300);
        setX(100);
        setY(100);
    setTitle("Stage One"); 
}
}
