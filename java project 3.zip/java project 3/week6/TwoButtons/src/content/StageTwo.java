/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package content;

import javafx.stage.Stage;

/**
 *
 * @author patel
 */
public class StageTwo extends Stage{
    public StageTwo(String title){
        setHeight(200);
        setWidth(50);
        setX(200);
        setY(500);
        setTitle(title);
    }
}
