/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package midterm;

/**
 *
 * @author patel
 */
public class Two extends First {
  public String stuff(){

        return "Two";

    }  

    public String change(){

        return "Three";

    }

    public String process(){

        return this.stuff();

    } 
}
