/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package midterm;

/**
 *
 * @author patel
 */
public class Five {

      private double digit = 1.0;

    

     public void setDigit(double digit){

          this.digit = digit;

     }
}
