/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package midterm;

import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author patel
 */
public class Midterm {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      //System.out.println(s1.substring(2));

   Two one = new Two();

     System.out.println(one.process());

      // TODO code application logic here
    }
}
    
    

