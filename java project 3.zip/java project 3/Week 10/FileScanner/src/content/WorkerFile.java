package content;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class WorkerFile {
        public static ArrayList<Worker> getWorker(String fileName) throws FileNotFoundException {

        ArrayList<Worker> workerList = new ArrayList<>();
        File file = new File(fileName);
        Scanner k = new Scanner(file);
        while (k.hasNext()) {
            // System.out.println(k.nextLine());
            int ID = k.nextInt();
            String first = k.next();
            String last = k.next();
            String name = first + " " + last;
           // System.out.println(ID + " name is " + name);
            Worker one=new Worker(ID);
            one.setName(name);
            workerList.add(one);
        }
        return workerList;

    }    
}
