package content;

public class Employee {

    private int hours;
    private double rate;

    public void setHours(int hours) {
        this.hours = hours;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }

    public int getHours() {
        return this.hours;
    }

    public double getRate() {
        return this.rate;
    }
}
