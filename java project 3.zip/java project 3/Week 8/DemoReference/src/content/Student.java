package content;
public class Student {
    private int ID;
    
    public void setID(int ID){
        this.ID = ID;
    }
    public int getID(){
        return ID;
    }
    
}
