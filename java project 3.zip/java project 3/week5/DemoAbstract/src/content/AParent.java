/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package content;

/**
 *
 * @author patel
 */
public  abstract class  AParent {
    public String printstuff(){
        return"This is printstuff";
    }
    public abstract String stuff();
    /*{
        return "This is Stuff";
        
    }*/
}
